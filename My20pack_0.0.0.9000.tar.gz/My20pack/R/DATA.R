#' Language data.
#' A dataset containing two colum: code and hello
#' @usage
#' language
#' @author
#' khadija Sossey ksossey@yahoo.fr
#' @format A data frame with 5 rows and 2 variables:
#' code: language code: "en", "fr", "it", "es", "de" for "English", "Fresh", "Italian", "Spanish", "German"
#' hello: word "hello"in the language corresponding to the code
#'
#'
language <- data.frame(code = c("en", "fr", "it", "es", "de"),
                       hello = c("Hello", "Bonjour", "Bonjourno", "Hola", "Hallo"))
